# AI Legal Draft Analyzer (Self-Learning)

## Features
- Upload drafts (PDF, Word, scanned images).
- Extract text and identify legal issues.
- Retrieve real case laws from Indian Kanoon API.
- Self-learning: Users can correct extracted issues, and the model learns over time.

## Setup
1. **Backend**:
    ```bash
    cd backend
    pip install -r requirements.txt
    export IKANOON_PUBLIC_KEY="your_public_key"
    export IKANOON_PRIVATE_KEY="your_private_key"
    uvicorn main:app --reload --port 8000
    ```

2. **Frontend**:
    ```bash
    cd frontend
    npm install
    npm start
    ```

3. Visit `http://localhost:3000`.
